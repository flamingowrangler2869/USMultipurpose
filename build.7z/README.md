# USMultipurpose

A keyboard layout designed with multiple ideas in mind:
 - complete compatibility with US-English
 - semi-complete compatibility with US-International
 - Spanish language
   - áÁ éÉ íÍ óÓ úÚ üÜ ñÑ ¡¿
 - other languages
   - «» çÇ áÁ åÅ æ ʒ ß
 - mathematics
   - ×÷≈ ¹²³⁴⁵⁶⁷⁸⁹⁰ ½⅓¼⅔¾ δΔ π φ γΓ µ λ ϕ ℓ ∞ ƒ ⟨⟩
 - miscellaneous
   - ° ¤£€¥ ¬¦ ©®™ ☭ … § “”

Complain/Suggest ideas in the "issues" tab
